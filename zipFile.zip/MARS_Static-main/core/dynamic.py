import os
import time
import subprocess
import threading
import yaml
from core.network import ScapyInterceptor

class DynamicController:
    def __init__(self, config_path="config/config.yaml"):
        # Load configuration
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
            
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
            
        self.vmx = self.config['sandbox']['vmx_path']
        self.vmrun = self.config['sandbox']['vmrun_path']
        self.auth = [
            "-gu", self.config['sandbox']['guest_user'], 
            "-gp", self.config['sandbox']['guest_pass']
        ]
        self.serial_pipe = self.config['sandbox']['serial_pipe']
        self.timeout = self.config['sandbox'].get('timeout_seconds', 60)
        
        self.is_analyzing = False
        
        # Structured Telemetry Dictionary for the Final Report
        self.telemetry = {
            "FR-DYN-01_Filesystem": [],
            "FR-DYN-02_Registry": [],
            "FR-DYN-03_Persistence": [],
            "FR-DYN-04_Processes": [],
            "FR-DYN-05_Memory": [],
            "FR-DYN-06_Network": [],
            "FR-DYN-07_Hardware": [],
            "System_Events": []
        }

        # Initialize network interceptor
        try:
            self.network_interceptor = ScapyInterceptor(config_path)
        except Exception as e:
            print(f"[-] Failed to initialize Network Interceptor: {e}")
            self.network_interceptor = None

    def _execute_vmrun(self, cmd_list, description=""):
        """Executes a vmrun command and handles errors."""
        if description:
            print(f"[*] {description}...")
            
        base_cmd = [self.vmrun, "-T", "ws"] + self.auth
        full_cmd = base_cmd + cmd_list
        
        try:
            result = subprocess.run(full_cmd, capture_output=True, text=True, check=True)
            return True
        except subprocess.CalledProcessError as e:
            print(f"[-] vmrun error during '{description}': {e.stderr.strip()}")
            return False
        except Exception as e:
            print(f"[-] OS error running vmrun during '{description}': {str(e)}")
            return False

    def _parse_and_route_telemetry(self, line):
        """Routes incoming serial logs to the correct report category."""
        # Check if the log belongs to one of our specific functional requirements
        if "[FR-DYN-01]" in line:
            self.telemetry["FR-DYN-01_Filesystem"].append(line)
        elif "[FR-DYN-02]" in line:
            self.telemetry["FR-DYN-02_Registry"].append(line)
        elif "[FR-DYN-03]" in line:
            self.telemetry["FR-DYN-03_Persistence"].append(line)
        elif "[FR-DYN-04]" in line:
            self.telemetry["FR-DYN-04_Processes"].append(line)
        elif "[FR-DYN-05]" in line:
            self.telemetry["FR-DYN-05_Memory"].append(line)
        elif "[FR-DYN-07]" in line:
            self.telemetry["FR-DYN-07_Hardware"].append(line)
        else:
            self.telemetry["System_Events"].append(line)

    def _telemetry_listener(self):
        """Background thread that captures live serial data from VM B."""
        print("[*] Telemetry listener waiting for VM pipe to open...")
        
        # Keep trying to connect to the named pipe (VMware creates it on boot)
        pipe_connected = False
        while self.is_analyzing and not pipe_connected:
            try:
                with open(self.serial_pipe, 'rb') as pipe:
                    pipe_connected = True
                    print("[+] Serial telemetry pipe connected successfully.")
                    
                    while self.is_analyzing:
                        line = pipe.readline().decode('utf-8', errors='ignore').strip()
                        if line:
                            print(f"[VM-B] {line}") # Print to console for live monitoring
                            self._parse_and_route_telemetry(line)
                            
            except FileNotFoundError:
                time.sleep(1) # Wait for VM to finish booting and create the pipe
            except Exception as e:
                print(f"[-] Telemetry pipe error: {e}")
                break

    def run_sandbox_analysis(self, target_exe_path):
        """Orchestrates the entire dynamic analysis lifecycle."""
        self.is_analyzing = True
        
        # 1. Revert to Clean State
        snapshot = self.config['sandbox']['snapshot_name']
        if not self._execute_vmrun(["revertToSnapshot", self.vmx, snapshot], f"Reverting to '{snapshot}'"):
            return {"error": "Failed to revert snapshot. Aborting dynamic analysis."}
        
        # 2. Power On Sandbox
        if not self._execute_vmrun(["start", self.vmx, "gui"], "Starting Sandbox VM"):
            return {"error": "Failed to start VM."}
            
        # 3. Start Telemetry Listener Thread
        listener = threading.Thread(target=self._telemetry_listener)
        listener.daemon = True
        listener.start()

        # 3.5 Start Network Interceptor
        if self.network_interceptor:
            print("[*] Starting Network Interceptor...")
            self.network_interceptor.start()

        # Wait for VMware Tools to initialize inside the guest OS
        print("[*] Waiting 15 seconds for Windows & VMware Tools to initialize...")
        time.sleep(15)

        # 4. Transfer Payloads to Sandbox
        guest_exe = r"C:\Users\Admin\Desktop\sample.exe"
        guest_agent = r"C:\Users\Admin\Desktop\unified_agent.py"
        host_agent = os.path.abspath("sandbox_agents/unified_agent.py")

        self._execute_vmrun(["copyFileFromHostToGuest", self.vmx, target_exe_path, guest_exe], "Uploading Malware Sample")
        self._execute_vmrun(["copyFileFromHostToGuest", self.vmx, host_agent, guest_agent], "Uploading Unified Agent")

        # 5. Execute Detonation
        print(f"[*] Detonating sample for {self.timeout} seconds...")
        
        # -noWait is critical: tells vmrun to trigger execution and immediately return control to this script
        self._execute_vmrun([
            "runProgramInGuest", self.vmx, "-noWait", "-interactive", 
            "C:\\Python39\\python.exe", guest_agent
        ], "Executing Unified Agent")

        # 6. Wait for the analysis window to conclude
        time.sleep(self.timeout + 5) # Add 5 seconds buffer for memory dumping/teardown
        
        # 7. Teardown
        print("[*] Dynamic analysis window complete. Tearing down...")
        self.is_analyzing = False
        listener.join(timeout=2)

        # Stop Network Interceptor
        if self.network_interceptor:
            print("[*] Stopping Network Interceptor...")
            captured_net = self.network_interceptor.stop()
            self.telemetry["FR-DYN-06_Network"] = [
                f"[{item['time']}] {item['type']} | {item['src']} -> {item['dst']} | {item['detail']}"
                for item in captured_net
            ]
        
        # Power off the VM to save host resources
        self._execute_vmrun(["stop", self.vmx, "hard"], "Powering off Sandbox")
        
        return self.telemetry

# ==========================================
# For standalone testing of this module
# ==========================================
if __name__ == "__main__":
    print("Testing DynamicController...")
    # Requires a valid config.yaml and VM setup to test natively
    # controller = DynamicController()
    # results = controller.run_sandbox_analysis("dummy_malware.exe")
    # print(results)